class Rooms:
    def __init__(self, room_name, room_description, room_items):
        self.room_name = room_name
        self.room_description = room_description
        self.room_items = room_items
