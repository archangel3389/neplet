import items_classes

item1= items_classes.Items("Sword", "A sharp sword", 50) 

print(item1.name)
print(item1.description)    
print(item1.value)
