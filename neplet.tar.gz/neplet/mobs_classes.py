class mobs:
    class wolf(mobs):
        def __init__(self, name, hp, atk, df, spd, exp, gold):
            self.name = name
            self.hp = hp
            self.atk = atk
            self.df = df
            self.spd = spd
            self.exp = exp
            self.gold = gold
            
    class bear(mobs):
        def __init__(self, name, hp, atk, df, spd, exp, gold):
            self.name = name
            self.hp = hp
            self.atk = atk
            self.df = df
            self.spd = spd
            self.exp = exp
            self.gold = gold
    
    class goblin(mobs):
        def __init__(self, name, hp, atk, df, spd, exp, gold):
            self.name = name
            self.hp = hp
            self.atk = atk
            self.df = df
            self.spd = spd
            self.exp = exp
            self.gold = gold